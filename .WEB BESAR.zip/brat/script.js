// Inline JavaScript
// TOGGLE
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('socialSidebar');
    const toggleIcon = document.getElementById('toggleIcon');

    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      toggleIcon.classList.toggle('fa-bars');
      toggleIcon.classList.toggle('fa-xmark');
      toggleIcon.classList.toggle('rotated');
    });

    document.addEventListener('click', (e) => {
      if (sidebar.classList.contains('open') &&
          !sidebar.contains(e.target) &&
          !toggleBtn.contains(e.target)) {
        sidebar.classList.remove('open');
        toggleIcon.classList.replace('fa-xmark', 'fa-bars');
        toggleIcon.classList.remove('rotated');
      }
    });

    // SELECTION
    const modeSelect = document.getElementById('modeSelect');
    const selectedText = document.getElementById('selectedText');
    const options = modeSelect.querySelectorAll('.option');
    let currentMode = '';

    document.getElementById('selectedMode').addEventListener('click', (e) => {
      e.stopPropagation();
      modeSelect.classList.toggle('active');
    });

    options.forEach(option => {
      option.addEventListener('click', (e) => {
        e.stopPropagation();
        const value = option.getAttribute('data-value');
        const text = option.querySelector('span').textContent;

        currentMode = value;
        selectedText.textContent = text;

        options.forEach(opt => {
          opt.classList.remove('selected');
          opt.querySelector('i').className = 'far fa-circle';
        });

        option.classList.add('selected');
        option.querySelector('i').className = 'fas fa-dot-circle';

        modeSelect.classList.remove('active');
      });
    });

    document.addEventListener('click', (e) => {
      if (!modeSelect.contains(e.target)) {
        modeSelect.classList.remove('active');
      }
    });

    // ELEMENT
    const textInput = document.getElementById('textInput');
    const generateBtn = document.getElementById('generateBtn');
    const downloadBtn = document.getElementById('downloadBtn');
    const previewContainer = document.querySelector('.preview-container');
    const placeholder = document.getElementById('placeholder');
    const loadingBar = document.getElementById('loadingBar');
    const toast = document.getElementById('toast');

    const API_STATIC = 'https://api.zenzxz.my.id/api/maker/brat';
    const API_ANIMATED = 'https://api.zenzxz.my.id/api/maker/bratvid';

    function showToast(message, type = 'info') {
      toast.textContent = message;
      toast.className = `toast ${type}`;
      toast.classList.add('show');
      setTimeout(() => toast.classList.remove('show'), 3000);
    }

    function clearPreview() {
      while (previewContainer.firstChild !== loadingBar) {
        if (previewContainer.firstChild) {
          previewContainer.removeChild(previewContainer.firstChild);
        } else {
          break;
        }
      }
      previewContainer.appendChild(placeholder);
    }

    function showPreview(element) {
      clearPreview();
      previewContainer.appendChild(element);
    }

    function buildUrl(text) {
      const base = currentMode === 'static' ? API_STATIC : API_ANIMATED;
      return `${base}?text=${encodeURIComponent(text)}&_ts=${Date.now()}`;
    }

    function sanitizeFilename(name) {
      return name.replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').substring(0, 50).trim() || 'brat';
    }

    async function generate() {
      const text = textInput.value.trim();
      if (!text) {
        showToast('Masukkan teks terlebih dahulu.', 'warning');
        return;
      }
      if (!currentMode) {
        showToast('Pilih mode terlebih dahulu.', 'warning');
        return;
      }

      const url = buildUrl(text);
      loadingBar.style.width = '100%';

      try {
        await new Promise(r => setTimeout(r, 600));
        const headResp = await fetch(url, { method: 'HEAD' });
        if (!headResp.ok) throw new Error('API unreachable');

        const img = document.createElement('img');
        img.src = url;
        img.alt = 'Preview';

        img.onload = () => {
          showToast(`${currentMode === 'static' ? 'PNG' : 'GIF'} siap!`, 'success');
          loadingBar.style.width = '0%';
        };

        img.onerror = () => {
          showToast('Gagal memuat gambar.', 'danger');
          clearPreview();
          loadingBar.style.width = '0%';
        };

        showPreview(img);
      } catch (err) {
        showToast('Gagal menghubungi API.', 'danger');
        clearPreview();
        loadingBar.style.width = '0%';
      }
    }

    async function download() {
      if (previewContainer.children.length <= 1) {
        showToast('Belum ada hasil. Tekan Generate dulu.', 'warning');
        return;
      }

      const text = textInput.value.trim();
      const url = buildUrl(text);
      const ext = currentMode === 'static' ? 'png' : 'gif';
      const filename = `${sanitizeFilename(text)}_Kyys_brat.${ext}`;

      try {
        const resp = await fetch(url);
        if (!resp.ok) throw new Error('Fetch failed');
        const blob = await resp.blob();
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(blobUrl);
        showToast('Download berhasil!', 'success');
      } catch (err) {
        showToast('Membuka di tab baru...', 'warning');
        window.open(url, '_blank');
      }
    }

    generateBtn.addEventListener('click', generate);
    downloadBtn.addEventListener('click', download);
    textInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') generate();
    });

