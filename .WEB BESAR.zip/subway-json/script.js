// Inline JavaScript
// === Toggle Sidebar ===
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('socialSidebar');
    const toggleIcon = document.getElementById('toggleIcon');

    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      toggleIcon.classList.toggle('fa-bars');
      toggleIcon.classList.toggle('fa-xmark');
      toggleIcon.classList.toggle('rotated');
    });

    document.addEventListener('click', (e) => {
      if (sidebar.classList.contains('open') &&
          !sidebar.contains(e.target) &&
          !toggleBtn.contains(e.target)) {
        sidebar.classList.remove('open');
        toggleIcon.classList.remove('fa-xmark', 'rotated');
        toggleIcon.classList.add('fa-bars');
      }
    });

