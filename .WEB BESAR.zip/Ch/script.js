// Inline JavaScript
const apiKeys=[
"3ef60c6adfe2c390129234dc6a19b2574d762105c41f2baf31eb8e4a7c8d44e0",
"94794542626da201fb6a1009245a09a84eff374878ad93e8af6c70fcb91d215a",
"fdbfda524d110bdb0206ad432227c2d491b65fee8862d60f3a990d0a87315da3",
"b423d23d06b48de5f3e58035d71c7137cd87a97d627a560f5c78e92659a0d364"
];

function showPopup(msg){
    document.getElementById("popupMsg").innerText=msg;
    document.getElementById("popupBg").style.display="flex";
}

document.getElementById("popupBtn").onclick=()=>{
    document.getElementById("popupBg").style.display="none";
};

async function sendReact(){
    const link=document.getElementById("link").value.trim();
    const emojiRaw=document.getElementById("emoji").value.trim();
    const resultBox=document.getElementById("resultBox");

    if(!link) return showPopup("Masukkan Link Dulu!");
    if(!emojiRaw) return showPopup("Masukkan Emoji Dulu!");

    const emoji=emojiRaw.replace(/,/g," ").split(/\s+/).filter(e=>e).join(",");

    resultBox.style.display="block";
    resultBox.innerHTML=`<div class="success"><b>Mengirim...</b></div><br><small>Sabar bentar...</small>`;

    let success=false;
    let lastError="Unknown error";

    for(let key of apiKeys){
        try{
            const url=`https://react.whyux-xec.my.id/api/rch?link=${encodeURIComponent(link)}&emoji=${encodeURIComponent(emoji)}`;

            const res=await fetch(url,{method:"GET",headers:{ "x-api-key":key }});
            const json=await res.json();

            if(json.success){
                resultBox.innerHTML=`
                <div class="success"><b>✔ BERHASIL</b></div><br>
                Target menerima: ${json.emojis.replace(/,/g," ")}<br>
                <small>Powered by Kyys Apeka</small>`;
                success=true;
                break;
            } else {
                lastError=json.error || "Unknown error";
            }

        } catch(e){
            lastError="Terjadi Kesalahan Sistem";
        }
    }

    if(!success){
        resultBox.innerHTML=`
        <div class="failed"><b>❌ GAGAL</b></div><br>
        Pesan: ${lastError}`;
    }
}

