const views = {
  input: document.getElementById('view-input'),
  result: document.getElementById('view-result')
};

function switchView(view) {
  views.input.style.display = view === 'input' ? 'block' : 'none';
  views.result.style.display = view === 'result' ? 'block' : 'none';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function goBackToInput() {
  switchView('input');
}

function openProfileModal() {
  document.getElementById('profileModal').style.display = 'flex';
}

function closeProfileModal() {
  document.getElementById('profileModal').style.display = 'none';
}

function formatFileSize(bytes) {
  if (!bytes) return '–';
  if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  if (bytes >= 1024) return (bytes / 1024).toFixed(2) + ' KB';
  return bytes + ' B';
}

function formatDate(ts) {
  if (!ts) return '–';
  return new Date(ts * 1000).toLocaleDateString('id-ID', {
    day: 'numeric', month: 'long', year: 'numeric'
  });
}

async function downloadBlobAuto(fileUrl, filename) {
  try {
    const btn = event?.currentTarget;
    const originalContent = btn ? btn.innerHTML : null;
    if (btn) btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

    const response = await fetch(fileUrl);
    if (!response.ok) throw new Error('Gagal mengambil file');

    const blob = await response.blob();
    const blobUrl = window.URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = blobUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();

    setTimeout(() => {
      window.URL.revokeObjectURL(blobUrl);
      document.body.removeChild(a);
      if (btn) btn.innerHTML = originalContent;
    }, 1000);

  } catch (e) {
    console.error("Blob error:", e);
    window.open(fileUrl, '_blank');
  }
}

function downloadVideo() {
  const data = JSON.parse(sessionStorage.getItem('tiktokData'));
  if (!data) return;
  const url = data.hdplay || data.play;
  downloadBlobAuto(url, `SnapBer_Video_${Date.now()}.mp4`);
}

function downloadAudio() {
  const data = JSON.parse(sessionStorage.getItem('tiktokData'));
  if (!data || !data.music_info?.play) return;
  downloadBlobAuto(data.music_info.play, `SnapBer_Audio_${Date.now()}.mp3`);
}

function downloadPhoto(url, index) {
  downloadBlobAuto(url, `SnapBer_Photo_${index + 1}.jpg`);
}

function downloadAllPhotos() {
  const data = JSON.parse(sessionStorage.getItem('tiktokData'));
  if (!data?.images) return;

  data.images.forEach((url, i) => {
    setTimeout(() => {
      downloadPhoto(url.trim(), i);
    }, i * 800);
  });
}

async function copyCaption() {
  const data = JSON.parse(sessionStorage.getItem('tiktokData'));
  const text = data?.title || '';
  try {
    await navigator.clipboard.writeText(text);
    alert('Caption disalin!');
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    ta.remove();
    alert('Caption disalin!');
  }
}

function renderResultData() {
  const raw = sessionStorage.getItem('tiktokData');
  if (!raw) return;

  const data = JSON.parse(raw);

  document.getElementById('videoTitle').textContent = data.title || 'Tanpa Judul';
  document.getElementById('videoDuration').textContent = data.duration || '0';
  document.getElementById('videoDate').textContent = formatDate(data.create_time);
  document.getElementById('videoRegion').textContent = data.region || 'ID';

  const thumb = document.getElementById('thumbnailImg');
  thumb.src = (data.cover || data.images?.[0] || '').trim();

  const isPhoto = Array.isArray(data.images) && data.images.length > 0;

  document.getElementById('videoInfoCard').style.display = 'block';
  document.getElementById('downloadSection').style.display = isPhoto ? 'none' : 'block';
  document.getElementById('photoSection').style.display = isPhoto ? 'block' : 'none';
  document.getElementById('musicSection').style.display = data.music_info ? 'block' : 'none';

  document.getElementById('videoSize').textContent = formatFileSize(data.hd_size || data.size);

  if (data.music_info) {
    document.getElementById('musicTitle').textContent = data.music_info.title || 'Music';
    document.getElementById('musicAuthor').textContent = data.music_info.author || 'Unknown';
    document.getElementById('musicCover').src = data.music_info.cover || '';
  }

  if (isPhoto) {
    const list = document.getElementById('photoList');
    list.innerHTML = '';
    data.images.forEach((url, i) => {
      const img = document.createElement('img');
      img.src = url.trim();
      img.className = 'photo-item';
      img.onclick = () => downloadPhoto(url.trim(), i);
      list.appendChild(img);
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('downloadBtn');
  const input = document.getElementById('urlInput');
  const loading = document.getElementById('loadingSection');
  const msg = document.getElementById('messageSection');
  const msgText = document.getElementById('messageText');

  btn.onclick = handleDownload;
  input.onkeypress = e => e.key === 'Enter' && handleDownload();

  async function handleDownload() {
    const url = input.value.trim();
    if (!url || !url.includes('tiktok.com')) {
      msgText.textContent = 'Link TikTok tidak valid!';
      msg.className = 'message-error';
      msg.style.display = 'block';
      return;
    }

    loading.style.display = 'block';
    msg.style.display = 'none';
    btn.disabled = true;

    try {
      const api = `https://api.zenzxz.my.id/api/downloader/tiktok?url=${encodeURIComponent(url)}`;
      const res = await fetch(api);
      const json = await res.json();

      if (json.success && json.data) {
        sessionStorage.setItem('tiktokData', JSON.stringify(json.data));
        renderResultData();
        switchView('result');
      } else {
        throw new Error();
      }
    } catch {
      msgText.textContent = 'Gagal mengambil data. Coba link lain.';
      msg.className = 'message-error';
      msg.style.display = 'block';
    } finally {
      loading.style.display = 'none';
      btn.disabled = false;
    }
  }
});

(() => {
  const loader = document.getElementById('loader');
  if (!loader) return;
  window.addEventListener('load', () => {
    setTimeout(() => {
      loader.style.opacity = '0';
      setTimeout(() => loader.remove(), 500);
    }, 500);
  });
})();

(() => {
  const easeOut = 'cubic-bezier(.2,.8,.2,1)';
  const cards = document.querySelectorAll(
    '.card, .input-section, .video-header, .download-card, .music-card, .photo-item, .step-item'
  );

  cards.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translate3d(0,32px,0) scale(.96)';
    el.style.transition = 'none';
    el.style.willChange = 'transform, opacity';
  });

  function onScroll() {
    const vh = window.innerHeight;
    cards.forEach((el, i) => {
      const rect = el.getBoundingClientRect();
      const visible = 1 - Math.min(Math.max(rect.top / vh, 0), 1);
      if (visible > 0.15) {
        el.style.transition = `transform .65s ${easeOut}, opacity .65s ${easeOut}`;
        el.style.opacity = '1';
        el.style.transform = `translate3d(0,${(1 - visible) * 18}px,0) scale(1)`;
      }
    });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('load', onScroll);
  window.addEventListener('resize', onScroll);

  let t = 0;
  function floatLoop() {
    t += 0.015;
    cards.forEach((el, i) => {
      const y = Math.sin(t + i) * 2;
      el.style.transform = el.style.transform.replace(/translate3d\\([^)]*\\)/, `translate3d(0,${y}px,0)`);
    });
    requestAnimationFrame(floatLoop);
  }
  requestAnimationFrame(floatLoop);

  document.addEventListener('pointerdown', e => {
    const btn = e.target.closest('button:not(.nav-btn):not(.nav-icon-btn)');
    if (!btn) return;
    btn.style.transition = 'transform .12s ease';
    btn.style.transform = 'scale(.93)';
  });

  document.addEventListener('pointerup', e => {
    const btn = e.target.closest('button:not(.nav-btn):not(.nav-icon-btn)');
    if (!btn) return;
    btn.style.transform = 'scale(1.05)';
    setTimeout(() => {
      btn.style.transition = 'transform .2s ease';
      btn.style.transform = 'scale(1)';
    }, 120);
  });

  document.querySelectorAll('input').forEach(input => {
    input.addEventListener('focus', () => {
      input.style.transition = 'transform .25s ease';
      input.style.transform = 'scale(1.035)';
    });
    input.addEventListener('blur', () => {
      input.style.transform = 'scale(1)';
    });
  });

  if (typeof window.switchView === 'function') {
    const original = window.switchView;
    window.switchView = view => {
      const input = document.getElementById('view-input');
      const result = document.getElementById('view-result');
      [input, result].forEach(v => {
        if (!v) return;
        v.style.transition = 'opacity .25s ease';
        v.style.opacity = '0';
      });
      setTimeout(() => {
        original(view);
        requestAnimationFrame(() => {
          const active = view === 'input' ? input : result;
          if (active) active.style.opacity = '1';
        });
      }, 180);
    };
  }
})();

