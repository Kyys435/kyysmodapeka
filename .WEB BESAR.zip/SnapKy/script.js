const menuItems = [
    {
      title: "TikTok Downloader",
      desc: "Download video tanpa watermark",
      icon: "fab fa-tiktok",
      url: "Snapber/TikTok-Downloader",
      coming: false
    },
    {
      title: "YouTube Downloader",
      desc: "Simpan video & audio YouTube",
      icon: "fab fa-youtube",
      url: "Snapber/Youtube-Downloader",
      coming: false
    },
    {
      title: "Instagram Downloader",
      desc: "Stories, Reels, & Posts",
      icon: "fab fa-instagram",
      url: "#",
      coming: true
    },
    {
      title: "Spotify Downloader",
      desc: "Download lagu & playlist",
      icon: "fab fa-spotify",
      url: "#",
      coming: true
    }
  ];

  const menuGrid = document.getElementById('menuGrid');
  menuGrid.innerHTML = menuItems.map(item => `
    <div class="menu-card ${item.coming ? 'coming-soon' : ''}" ${!item.coming ? `onclick="window.location.href='${item.url}'"` : ''}>
      <div class="menu-icon"><i class="${item.icon}"></i></div>
      <div class="menu-title">${item.title}</div>
      <div class="menu-desc">${item.desc}</div>
      ${item.coming ? '<span class="coming-tag">COMING SOON</span>' : ''}
    </div>
  `).join('');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add('reveal');
    });
  }, { threshold: 0.1 });
  document.querySelectorAll('.menu-card').forEach(card => observer.observe(card));

  const isVip = localStorage.getItem('isVip') === 'true';
  const vipUser = localStorage.getItem('vipUserId');

function openProfile() {
  const content = document.getElementById('profileContent');

  const isVip = localStorage.getItem('isVip') === 'true';
  const vipUserId = localStorage.getItem('vipUserId');

  if (isVip && vipUserId) {
    content.innerHTML = `
      <div class="text-gray-400 text-sm">Username</div>
      <div class="font-bold text-xl text-white">${vipUserId}</div>
      <div class="vip-badge">VIP MEMBER</div>
    `;
  } else {
    content.innerHTML = `
      <div class="text-sm text-gray-300">Anda belum memiliki akses VIP.</div>
      <a href="VIP" class="block mt-3 py-2 rounded-xl bg-[#FFD700] text-black font-bold text-center transition hover:opacity-90">
        <i class="fas fa-crown mr-2"></i>Upgrade to VIP
      </a>
    `;
  }

  document.getElementById('profileModal').classList.remove('hidden');
  document.getElementById('profileModal').classList.add('flex');
}

  function closeProfile() {
    document.getElementById('profileModal').classList.add('hidden');
    document.getElementById('profileModal').classList.remove('flex');
  }

  function openChangelog() {
    document.getElementById('changelogModal').classList.remove('hidden');
    document.getElementById('changelogModal').classList.add('flex');
  }

  function closeChangelog() {
    document.getElementById('changelogModal').classList.add('hidden');
    document.getElementById('changelogModal').classList.remove('flex');
  }

