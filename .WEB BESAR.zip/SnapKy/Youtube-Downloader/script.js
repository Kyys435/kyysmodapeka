// External JS: https://cdn.tailwindcss.com

// Inline JavaScript
function switchView(view) {
  const inputView = document.getElementById('view-input');
  const resultView = document.getElementById('view-result');
  if (view === 'result') {
    inputView.style.display = 'none';
    resultView.style.display = 'block';
  } else {
    inputView.style.display = 'block';
    resultView.style.display = 'none';
  }
}

function downloadBlobAuto(url, filename) {
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function getQualityLabel(res) {
  if (res >= 1080) return 'FHD';
  if (res >= 720) return 'HD';
  if (res >= 480) return 'SD';
  return 'LOW';
}

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.getElementById('downloadBtn');
  const input = document.getElementById('urlInput');
  const reso = document.getElementById('resolutionInput');
  const loading = document.getElementById('loadingSection');
  const msg = document.getElementById('messageSection');
  const msgText = document.getElementById('messageText');

  btn.onclick = handleDownload;
  input.onkeypress = e => e.key === 'Enter' && handleDownload();

  async function handleDownload() {
    const url = input.value.trim();
    const resolution = reso.value;

    if (!url || !url.includes('youtu')) {
      msgText.textContent = 'Link YouTube tidak valid!';
      msg.className = 'message-error';
      msg.style.display = 'block';
      return;
    }

    loading.style.display = 'block';
    msg.style.display = 'none';
    btn.disabled = true;

    try {
      // ✅ Perbaikan: HAPUS SPASI setelah '='
      const apiVideo = `https://api.zenzxz.my.id/api/downloader/ytmp4v2?url=${encodeURIComponent(url)}&resolution=${resolution}`;
      const apiAudio = `https://api.zenzxz.my.id/api/downloader/ytmp3v2?url=${encodeURIComponent(url)}`;

      const [vRes, aRes] = await Promise.all([
        fetch(apiVideo).then(r => r.json()),
        fetch(apiAudio).then(r => r.json())
      ]);

      if (!vRes.success || !aRes.success) throw new Error('API error');

      const data = {
        video: vRes.data,
        audio: aRes.data,
        resolution: resolution,
        time: vRes.timestamp
      };

      sessionStorage.setItem('ytData', JSON.stringify(data));
      switchView('result');
      setTimeout(() => renderYTResult(), 100);
    } catch (e) {
      console.error(e);
      msgText.textContent = 'Gagal mengambil data YouTube.';
      msg.className = 'message-error';
      msg.style.display = 'block';
    } finally {
      loading.style.display = 'none';
      btn.disabled = false;
    }
  }
});

function renderYTResult() {
  const raw = sessionStorage.getItem('ytData');
  if (!raw) return;
  const { video, audio, resolution, time } = JSON.parse(raw);

  const videoInfoCard = document.getElementById('videoInfoCard');
  const downloadSection = document.getElementById('downloadSection');
  const musicSection = document.getElementById('musicSection');

  document.getElementById('videoTitle').textContent = video.title || 'Video Tidak Diketahui';
  document.getElementById('videoDuration').textContent = video.duration || '?';
  document.getElementById('videoDate').textContent = new Date(time).toLocaleString('id-ID');
  document.getElementById('videoRegion').textContent = 'YouTube';
  document.getElementById('thumbnailImg').src = video.thumbnail || '';

  videoInfoCard.style.display = 'block';
  downloadSection.style.display = 'block';
  musicSection.style.display = 'block';
  document.getElementById('photoSection').style.display = 'none';
  document.getElementById('videoSize').textContent = video.format || '?';

  document.getElementById('musicTitle').textContent = audio.title || 'Audio';
  document.getElementById('musicAuthor').textContent = 'MP3 Audio';
  document.getElementById('musicCover').src = audio.thumbnail || '';

  // ✅ Set resolusi & badge
  window.__ytVideo = video.download_url;
  window.__ytAudio = audio.download_url;
  window.__ytResolution = resolution;
  document.getElementById('qualityBadge').textContent = getQualityLabel(Number(resolution));
}

function downloadVideo() {
  if (window.__ytVideo) downloadBlobAuto(window.__ytVideo, `SnapBer_YT_${Date.now()}.mp4`);
}

function downloadAudio() {
  if (window.__ytAudio) downloadBlobAuto(window.__ytAudio, `SnapBer_YT_${Date.now()}.mp3`);
}

function goBackToInput() {
  switchView('input');
}

function copyCaption() {
  const title = document.getElementById('videoTitle')?.textContent?.trim();
  if (!title) {
    alert('Tidak ada caption untuk disalin.');
    return;
  }

  if (navigator.clipboard) {
    navigator.clipboard.writeText(title).then(() => {
      const btn = document.querySelector('.btn-copy-caption');
      const originalText = btn.innerHTML;
      btn.innerHTML = '<i class="fas fa-check"></i> Tersalin!';
      setTimeout(() => { btn.innerHTML = originalText; }, 2000);
    }).catch(() => fallbackCopyTextToClipboard(title));
  } else {
    fallbackCopyTextToClipboard(title);
  }
}

function fallbackCopyTextToClipboard(text) {
  const textArea = document.createElement("textarea");
  textArea.value = text;
  textArea.style.position = "fixed";
  textArea.style.opacity = "0";
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  try {
    const successful = document.execCommand('copy');
    if (successful) {
      const btn = document.querySelector('.btn-copy-caption');
      const originalText = btn.innerHTML;
      btn.innerHTML = '<i class="fas fa-check"></i> Tersalin!';
      setTimeout(() => { btn.innerHTML = originalText; }, 2000);
    } else {
      alert('Gagal menyalin. Silakan salin manual.');
    }
  } catch (err) {
    alert('Browser tidak mendukung fitur salin. Silakan salin manual.');
  }
  document.body.removeChild(textArea);
}

function downloadThumbnail() {
  const thumbnailUrl = document.getElementById('thumbnailImg')?.src;
  if (!thumbnailUrl) {
    alert('Thumbnail tidak tersedia.');
    return;
  }
  const a = document.createElement('a');
  a.href = thumbnailUrl;
  a.download = `SnapBer_Thumbnail_${Date.now()}.jpg`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function openProfileModal() {
  document.getElementById('profileModal').style.display = 'flex';
}
function closeProfileModal() {
  document.getElementById('profileModal').style.display = 'none';
}

// Inline JavaScript
(() => {
  const easeOut = 'cubic-bezier(.2,.8,.2,1)';
  const cards = document.querySelectorAll(
    '.card, .input-section, .video-header, .download-card, .music-card, .photo-item, .step-item'
  );

  cards.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translate3d(0,32px,0) scale(.96)';
    el.style.transition = 'none';
    el.style.willChange = 'transform, opacity';
  });

  function onScroll() {
    const vh = window.innerHeight;
    cards.forEach((el, i) => {
      const rect = el.getBoundingClientRect();
      const visible = 1 - Math.min(Math.max(rect.top / vh, 0), 1);
      if (visible > 0.15) {
        el.style.transition = `transform .65s ${easeOut}, opacity .65s ${easeOut}`;
        el.style.opacity = '1';
        el.style.transform = `translate3d(0,${(1 - visible) * 18}px,0) scale(1)`;
      }
    });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('load', onScroll);
  window.addEventListener('resize', onScroll);

  let t = 0;
  function floatLoop() {
    t += 0.015;
    cards.forEach((el, i) => {
      const y = Math.sin(t + i) * 2;
      el.style.transform = el.style.transform.replace(/translate3d\([^)]*\)/, `translate3d(0,${y}px,0)`);
    });
    requestAnimationFrame(floatLoop);
  }
  requestAnimationFrame(floatLoop);

  document.addEventListener('pointerdown', e => {
    const btn = e.target.closest('button:not(.nav-btn):not(.nav-icon-btn)');
    if (!btn) return;
    btn.style.transition = 'transform .12s ease';
    btn.style.transform = 'scale(.93)';
  });

  document.addEventListener('pointerup', e => {
    const btn = e.target.closest('button:not(.nav-btn):not(.nav-icon-btn)');
    if (!btn) return;
    btn.style.transform = 'scale(1.05)';
    setTimeout(() => {
      btn.style.transition = 'transform .2s ease';
      btn.style.transform = 'scale(1)';
    }, 120);
  });

  document.querySelectorAll('input').forEach(input => {
    input.addEventListener('focus', () => {
      input.style.transition = 'transform .25s ease';
      input.style.transform = 'scale(1.035)';
    });
    input.addEventListener('blur', () => {
      input.style.transform = 'scale(1)';
    });
  });

  if (typeof window.switchView === 'function') {
    const original = window.switchView;
    window.switchView = view => {
      const input = document.getElementById('view-input');
      const result = document.getElementById('view-result');
      [input, result].forEach(v => {
        if (!v) return;
        v.style.transition = 'opacity .25s ease';
        v.style.opacity = '0';
      });
      setTimeout(() => {
        original(view);
        requestAnimationFrame(() => {
          const active = view === 'input' ? input : result;
          if (active) active.style.opacity = '1';
        });
      }, 180);
    };
  }
})();

// Inline JavaScript
(() => {
  const getVip = () => localStorage.getItem('isVip') === 'true' && localStorage.getItem('vipUserId');

  const resSelect = document.getElementById('resolutionInput');
  const downloadBtn = document.getElementById('downloadBtn');

  function showVipAlert() {
    if (document.getElementById('vipGuardModal')) return;

    const modal = document.createElement('div');
    modal.id = 'vipGuardModal';
    modal.innerHTML = `
      <div style="position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.6);backdrop-filter:blur(8px)">
        <div style="background:#131627;border-radius:18px;border:1px solid rgba(255,255,255,.08);width:90%;max-width:340px;padding:26px;text-align:center;box-shadow:0 20px 40px rgba(0,0,0,.5);animation:pop .35s ease">
          <div style="font-size:48px;margin-bottom:12px;color:#facc15">
            <i class="fas fa-crown"></i>
          </div>
          <h3 style="font-family:Orbitron;color:white;font-size:1.25rem;margin-bottom:8px">
            Fitur VIP Terkunci
          </h3>
          <p style="color:#a8aab7;font-size:.95rem;margin-bottom:18px">
            Resolusi <b>1080p</b> hanya tersedia untuk member VIP.
          </p>
          <div style="display:flex;gap:10px">
            <button id="vipCancel" style="flex:1;padding:12px;border-radius:999px;background:#1f2937;color:white;border:none">
              Batal
            </button>
            <button id="vipGo" style="flex:1;padding:12px;border-radius:999px;background:linear-gradient(90deg,#facc15,#f59e0b);color:black;font-weight:700;border:none">
              Upgrade VIP
            </button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    modal.querySelector('#vipCancel').onclick = () => modal.remove();
    modal.querySelector('#vipGo').onclick = () => location.href = 'https://berrymodapeka.edgeone.app/VIP';

    const style = document.createElement('style');
    style.textContent = `
      @keyframes pop {
        from { transform:scale(.7); opacity:0 }
        to   { transform:scale(1); opacity:1 }
      }
    `;
    document.head.appendChild(style);
  }

  function guard1080() {
    if (resSelect.value === '1080' && !getVip()) {
      resSelect.value = '720';
      showVipAlert();
      return false;
    }
    return true;
  }

  resSelect.addEventListener('change', guard1080);
  downloadBtn.addEventListener('click', e => {
    if (!guard1080()) e.stopImmediatePropagation();
  });

})();

