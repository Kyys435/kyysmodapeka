// Inline JavaScript
document.querySelectorAll('.feature-item').forEach(item => {
      const header = item.querySelector('.feature-header');
      const detail = item.querySelector('.detail');
      const icon = item.querySelector('.toggle-icon');

      header.addEventListener('click', () => {
        const isOpen = detail.style.maxHeight && detail.style.maxHeight !== '0px';

        // Tutup semua yang lain
        document.querySelectorAll('.detail').forEach(d => {
          if (d !== detail) d.style.maxHeight = '0';
        });
        document.querySelectorAll('.toggle-icon').forEach(i => {
          if (i !== icon) i.style.transform = 'rotate(0deg)';
        });

        // Toggle current
        detail.style.maxHeight = isOpen ? '0' : detail.scrollHeight + 'px';
        icon.style.transform = isOpen ? 'rotate(0deg)' : 'rotate(180deg)';
      });
    });
    
    (function () {
      const loader = document.getElementById('loader');
      if (!loader) return;

      const hideLoader = () => {
        loader.style.opacity = '0';
        loader.style.pointerEvents = 'none';
        setTimeout(() => loader.remove(), 300);
      };

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', hideLoader);
      } else {
        hideLoader();
      }
    })();

